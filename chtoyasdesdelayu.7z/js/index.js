function tea(){
    window.location.href = "https://www.tinkoff.ru/cf/1m2TAb1uMse";
}

window.onload = function(){
    console.log('привет')
}